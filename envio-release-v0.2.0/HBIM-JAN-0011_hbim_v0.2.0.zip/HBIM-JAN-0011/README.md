# HBIM-JAN-0011 — Janela 11

## Modelo IFC4 da versão 0.2.0

- Arquivo `ifc/HBIM-JAN-0011_janela-hbim_v0.2.0.ifc`.
- Vão de **1,208 × 2,803 m** (largura × altura). Escala métrica preservada do OBJ dimensionado de origem.
- Geometria reconstruída a partir do OBJ fotogramétrico, com 23 sólidos.
- Origem local no centro da base do vão, no plano do vidro, com Z na vertical.
- Materiais registrados: Acabamento mineral, Madeira, Vidro.

Abra ou vincule o IFC no Revit ou use um visualizador BIM. O modelo tem detalhes simplificados, sem texturas fotográficas e sem os parâmetros de edição de uma família Revit nativa. As dimensões representam o modelo e devem ser verificadas em campo quando necessário.

[Baixar o pacote v0.2.0](https://github.com/Pedrovisk26/biblioteca-hbim-arcos/releases/download/v0.2.0/HBIM-JAN-0011_hbim_v0.2.0.zip) · [Notas da versão](https://github.com/Pedrovisk26/biblioteca-hbim-arcos/releases/tag/v0.2.0)

Autoria: Pedro Lucas Coutinho e Raquel Ribeiro. Licença: CC BY 4.0.
